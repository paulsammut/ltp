/* 
 * File:   tests.h
 * Author: paul
 *
 * Created on February 2, 2017, 9:38 AM
 */

#ifndef TESTS_H
#define	TESTS_H

#ifdef	__cplusplus
extern "C" {
#endif

void test1(void);
void test2(void);
void test3(void);
void test4(void);
void test5(void);



#ifdef	__cplusplus
}
#endif

#endif	/* TESTS_H */

