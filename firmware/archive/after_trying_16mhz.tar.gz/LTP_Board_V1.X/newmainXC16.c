/*
 * File:   newmainXC16.c
 * Author: paul
 *
 * Created on January 4, 2017, 1:49 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
